function load() {
    // App Load Code
}

// App Code